package domain;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Vector;

import javax.persistence.*;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlID;
import javax.xml.bind.annotation.XmlIDREF;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

@XmlAccessorType(XmlAccessType.FIELD)
@Entity
public class Driver extends Pasajero implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String name;
	
	private boolean hasBussiness=false;
	private Business bussiness=null;
	
	@OneToMany(fetch=FetchType.EAGER, cascade=CascadeType.PERSIST)
	private ArrayList<Oferta> ofertas;
	@XmlIDREF
	@OneToMany(fetch=FetchType.EAGER, cascade=CascadeType.PERSIST)
	private List<Ride> rides=new Vector<Ride>();
	
	@XmlIDREF
	@OneToMany(fetch=FetchType.EAGER, cascade=CascadeType.PERSIST)
	private ArrayList<Vehiculo> vehiculos;
	
	public Driver(String email,String password) {
		super(email,password);
		
	}

	public Driver(String email, String password,String name) {
		super(email,password);
		this.name = name;
		hasBussiness=false;
		vehiculos=new ArrayList<Vehiculo>();
		ofertas=new ArrayList<Oferta>();
		
	}
	
	


	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	
	
	public String toString(){
		return "Email: "+ getEmail() +" Nombre: "+name + " Rides: "+rides;
	}
	
	/**
	 * This method creates a bet with a question, minimum bet ammount and percentual profit
	 * 
	 * @param question to be added to the event
	 * @param betMinimum of that question
	 * @return Bet
	 */
	public Ride addRide(String from, String to, Date date, int nPlaces, float price, Vehiculo vehiculo)  {
        Ride ride=new Ride(from,to,date,nPlaces,price, this,vehiculo);
        rides.add(ride);
        return ride;
	}

	/**
	 * This method checks if the ride already exists for that driver
	 * 
	 * @param from the origin location 
	 * @param to the destination location 
	 * @param date the date of the ride 
	 * @return true if the ride exists and false in other case
	 */
	public boolean doesRideExists(String from, String to, Date date)  {	
		for (Ride r:rides)
			if ( (java.util.Objects.equals(r.getFrom(),from)) && (java.util.Objects.equals(r.getTo(),to)) && (java.util.Objects.equals(r.getDate(),date)) )
			 return true;
		
		return false;
	}
		
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Driver other = (Driver) obj;
		if (getEmail() != other.getEmail())
			return false;
		return true;
	}

	public Ride removeRide(String from, String to, Date date) {
		boolean found=false;
		int index=0;
		Ride r=null;
		while (!found && index<=rides.size()) {
			r=rides.get(++index);
			if ( (java.util.Objects.equals(r.getFrom(),from)) && (java.util.Objects.equals(r.getTo(),to)) && (java.util.Objects.equals(r.getDate(),date)) )
			found=true;
		}
			
		if (found) {
			rides.remove(index);
			return r;
		} else return null;
	}
	
	public void addRide(Ride r) {
		this.rides.add(r);
	}
	
	public List<Ride> getRides (){
		List<Ride> res = null;
		res= this.rides;
		
		return res;
	}

	public boolean hasBussiness() {
		return hasBussiness;
	}

	public void setHasBussiness(boolean hasBussiness) {
		this.hasBussiness = hasBussiness;
		bussiness=null;
	}

	public Business getBussiness() {
		return bussiness;
	}

	public void setBussiness(Business bussiness) {
		this.bussiness = bussiness;
	}
	
	public ArrayList<Vehiculo> getVehiculos() {
		return vehiculos;
	}
	public void setVehiculos(ArrayList<Vehiculo> pVehiculos) {
		vehiculos=pVehiculos;
	}
	public Vehiculo addVehiculo(Vehiculo pVehiculo) {
		vehiculos.add(pVehiculo);
		return pVehiculo;
	}
	
	public Ride findSame(Ride r) {
		Ride res= null;
		
		for (Ride i : this.rides) {
			if (r.itsSame(i)) {
				res= i;
			}
		}
		
		return res;
	}

	public ArrayList<Oferta> getOfertas() {
		return ofertas;
	}

	public void setOfertas(ArrayList<Oferta> ofertas) {
		this.ofertas = ofertas;
	}
	
	public void addOferta(Oferta pOferta) {
		ofertas.add(pOferta);
	}
	

}
